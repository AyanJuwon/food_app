<div class="container">
    <table class="table table-wishlist table-mobile">
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Status</th>
                <th></th>
                <th></th>
            </tr>
        </thead>

        <tbody>
            <tr>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = \App\Models\OrderDetail::where('order_id', $order->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                        <?php $__currentLoopData = \App\Models\Menu::where('id', $orderDetail->menu_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <td class="product-col">
                                <div class="product">
                                    <figure class="product-media">
                                        <a href="#">
                                            <img src="<?php echo e(asset('uploads/menu/' . $menu->menu_image)); ?>"
                                                alt="Product image">
                                        </a>
                                    </figure>

                                    <h3 class="product-title">
                                        <a href="#"><?php echo e($menu->menu_name); ?></a>
                                    </h3><!-- End .product-title -->
                                </div><!-- End .product -->
                            </td>
                            <td class="price-col">$<?php echo e($menu->menu_price); ?></td>
                            <td class="stock-col">
                                <?php if($order->tracking == 0): ?>
                                    <span class="out-of-stock">In Transit</span>

                                <?php endif; ?>
                                <?php if($order->tracking == 1): ?>

                                    <span class="in-stock">Completed</span>
                                <?php else: ?>
                                    <?php if($order->tracking == 2): ?>

                                        <span class="out-of-stock">Cancelled</span>
                                    <?php endif; ?>

                                <?php endif; ?>
                                

                            </td>
                            
                            <td class="action-col">
                                <a href="<?php echo e(route('myOrder', $order)); ?>" class="btn btn-block btn-outline-primary-2">
                                    See Details


                                </a>


                            </td>
                            <td class="remove-col"><button class="btn-remove"><i class="icon-close"></i></button></td>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </tbody>
    </table><!-- End .table table-wishlist -->
    <div class="wishlist-share">
        <div class="social-icons social-icons-sm mb-2">
            <label class="social-label">Share on:</label>
            <a href="#" class="social-icon" title="Facebook" target="_blank"><i class="icon-facebook-f"></i></a>
            <a href="#" class="social-icon" title="Twitter" target="_blank"><i class="icon-twitter"></i></a>
            <a href="#" class="social-icon" title="Instagram" target="_blank"><i class="icon-instagram"></i></a>
            <a href="#" class="social-icon" title="Youtube" target="_blank"><i class="icon-youtube"></i></a>
            <a href="#" class="social-icon" title="Pinterest" target="_blank"><i class="icon-pinterest"></i></a>
        </div><!-- End .soial-icons -->
    </div><!-- End .wishlist-share -->
</div><!-- End .container -->
<?php /**PATH C:\Users\OHHJAY\Desktop\food_app\food_app\resources\views/orders.blade.php ENDPATH**/ ?>