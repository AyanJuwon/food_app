

<?php $__env->startSection('css'); ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('asset/styles/store.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/styles/orders.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <main class="m-5 main">

        <div class="container">
            <div class="sheet">
                <section class="header">
                    <h3>Order Details</h3>
                </section>
                <section class="order-meta">
                    <p class="meta-data">order no
                        <?php echo $order_id; ?></p>
                    <p class="meta-data">placed on :<?php echo e($order->created_at->toDateString()); ?></p>
                    <p class="meta-data">total : $<?php echo e($order->total); ?></p>
                </section>
                <section class="order-details">
                    <h4>Items In Your Order</h4>

                    <?php $__currentLoopData = \App\Models\OrderDetail::where('order_id', $order_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = \App\Models\Menu::where('id', $orderDetail->product_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                            <div class="story-card flex-container">

                                <div class="story-card__body-story">

                                    <div class="story-card__body-left">
                                        <img src="<?php echo e(asset('uploads/menu/' . $menu->product_image)); ?>}"
                                            alt="<?php echo e($menu->product_image); ?>" class="story-card__story-img">
                                    </div>

                                    <div class="story-card__body-right">
                                        <div class="story-card__header">

                                            <div class="story-card__info">
                                                <h6><?php echo e($menu->product_name); ?></h6>
                                            </div>

                                        </div>
                                        <p class="memorial-card-content">
                                        <p>Order No: <?php echo e($order->id); ?> </p>
                                        <p>Quantity: <?php echo e($orderDetail->quantity); ?> </p>
                                        <div>
                                            <?php if($order->tracking == 0): ?>
                                                <span class="out-of-stock">In Transit</span>

                                            <?php endif; ?>
                                            <?php if($order->tracking == 1): ?>

                                                <span class="in-stock">Completed</span>
                                            <?php else: ?>
                                                <?php if($order->tracking == 2): ?>

                                                    <span class="out-of-stock">Cancelled</span>
                                                <?php endif; ?>

                                            <?php endif; ?>
                                        </div>
                                        <p class="story-card__date">Ordered on:
                                            <?php echo e($order->created_at->toDateString()); ?>

                                        </p>
                                        <p class="story-card__date">Price:
                                            $<?php echo e($menu->product_price); ?>

                                        </p>
                                        <a href="<?php echo e(route('menu', $menu->id)); ?>" class="memorial-card-button">Buy
                                            Again</a>
                                        <a href="#" class="memorial-card-button">Track
                                            Order</a>
                                        </p>
                                    </div>
                                </div>

                            </div>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </section>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="card">
                                <div class="card-header">
                                    Payment Information
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Payment Details</h5>
                                    <p class="card-text text-secondary  ">Paid with Paystacks</p>
                                    <p class="card-text text-secondary">Items Total: $<?php echo e($order->total - 10); ?> </p>
                                    <p class="card-text text-secondary">Delivery Fee: $100 </p>
                                    <p class="card-text ">Total: $<?php echo e($order->total); ?> </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="card">
                                <div class="card-header">
                                    Delivery Information
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Delivery Address</h5>
                                    <p class="card-text text-secondary">Address: <?php echo e($order->address); ?></p>
                                    <p class="card-text text-secondary">Address: <?php echo e($order->phoneNumber); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OHHJAY\Desktop\food_app\food_app\resources\views/order.blade.php ENDPATH**/ ?>