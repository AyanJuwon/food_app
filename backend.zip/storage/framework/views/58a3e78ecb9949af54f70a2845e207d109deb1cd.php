<?php
/**
* essential-foods
* Olamiposi
* 23/04/2021
* 07:04
* CREATED WITH PhpStorm
**/
?>


<?php $__env->startSection('title'); ?>
    All menus
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('asset/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('asset/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive Datatable css -->
    <link href="<?php echo e(asset('asset/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="breadcrumbbar">
        <div class="row align-items-center">
            <div class="col-md-8 col-lg-8">
                <h4 class="page-title">All menus</h4>
                <div class="breadcrumb-list">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#">Manage menus</a></li>
                        <li class="breadcrumb-item active" aria-current="page">All menus</li>
                    </ol>
                </div>
            </div>
            <div class="col-md-4 col-lg-4">
                <div class="widgetbar">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary-rgba"><i
                            class="feather icon-skip-back mr-2"></i>Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>

    <div class="contentbar">
        <!-- Start row -->
        <div class="row">
            <!-- Start col -->
            <div class="col-lg-12">
                <div class="card m-b-30">
                    <div class="card-header">
                        <h5 class="card-title">All menus</h5>
                    </div>
                    <?php echo $__env->make('partials.list_error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable-buttons" class="display table table-bordered">
                                <thead>
                                    <tr>
                                        <th>menu Name</th>
                                        <th>Amount</th>
                                        <th>Category</th>
                                        <th>Created at</th>
                                        <th>View</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($menu->menu_name); ?></td>
                                            <td><?php echo e($menu->amount); ?></td>
                                            <td><?php echo e($menu->category); ?></td>
                                            <td><?php echo e($menu->created_at->toDateString()); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('menu.show', $menu->id)); ?>" type="button"
                                                    class="btn btn-primary-rgba"><i class="feather icon-send mr-2"></i>
                                                    View</a>
                                            </td>
                                            <td>
                                                <div class="single-dropdown">
                                                    <div class="dropdown">
                                                        <a class="btn btn-primary-rgba dropdown-toggle" href="#"
                                                            role="button" id="dropdownMenuLink" data-toggle="dropdown"
                                                            aria-haspopup="true" aria-expanded="false">
                                                            Action
                                                        </a>
                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('menu.edit', $menu->id)); ?>">Edit</a>
                                                            <a class="dropdown-item"
                                                                onclick="handleDelete('<?php echo e($menu->id); ?>')">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>menu Name</th>
                                        <th>Amount</th>
                                        <th>Category</th>
                                        <th>Created at</th>
                                        <th>View</th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End col -->
            <!-- Start col -->
        </div>
        <!-- End row -->
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        function handleDelete(id) {
            $('#deleteModal').modal({
                backdrop: 'static',
                keyboard: false
            });
            var form = document.getElementById('deleteForm');
            var url = '<?php echo e(route('menu.destroy', [':id'])); ?>';
            url = url.replace(':id', id);
            form.action = url;
        }

    </script>
    <script src="<?php echo e(asset('asset/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/custom/custom-table-datatable.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OHHJAY\Desktop\food_app\food_app\resources\views/admin/menus/index.blade.php ENDPATH**/ ?>