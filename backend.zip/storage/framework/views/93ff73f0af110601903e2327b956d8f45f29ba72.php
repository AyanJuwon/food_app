


<?php $__env->startSection('css'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/vendor/animate/animate.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/vendor/select2/select2.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/vendor/perfect-scrollbar/perfect-scrollbar.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/styles/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/styles/main.css')); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive Datatable css -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet"
        type="text/css" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-table100">
        <div class="wrap-table100">
            <div class="table100">
                <table>
                    <thead>
                        <tr class="table100-head">
                            <th class="column1">Date</th>
                            <th class="column2">Order ID</th>
                            <th class="column5">Order Quantity</th>
                            <th class="column6">Total</th>
                            <th class="column7">Reference</th>
                            <th class="column8">Status</th>
                            <th class="column9">See Details</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php $cart_quantity = 0; ?>
                            <tr>
                                <td class="column1"><?php echo e($order->created_at->toDateString()); ?></td>
                                <td class="column2"><?php echo e($order->id); ?></td>


                                <td class="column5">
                                    <?php $__currentLoopData = \App\Models\OrderDetail::where('order_id', $order->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $cart_quantity += $orderDetail->quantity; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $cart_quantity; ?>
                                </td>

                                <td class="column6">$<?php echo e($order->total); ?></td>
                                <td class="column7"><?php echo e($order->payment_id); ?></td>
                                <td class="column8">
                                    <form hidden id="completeForm"
                                        action="<?php echo e(route('admin.completeOrder', [$order->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?><button type="submit" class="btn btn-success">Complete Order</button></form>
                                    <form hidden id="cancelForm" action="<?php echo e(route('admin.cancelOrder', [$order->id])); ?>"
                                        method="post">
                                        <?php echo csrf_field(); ?><button type="submit" class="btn btn-danger">Cancel Order</button></form>

                                    <p><a href="#" class="text-success" onclick="event.preventDefault();document.getElementById('completeForm').submit();
        ">Complete Order</a>/<a href="#" onclick="event.preventDefault();document.getElementById('cancelForm').submit();
        " class="text-danger">Cancel Order</a></p>
            </div>
            </td>
            <td class="column9"><a href="<?php echo e(route('adminViewOrder', $order)); ?>" class="text-primary">See Details</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('asset/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(asset('asset/vendor/bootstrap/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.2/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.0/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(asset('asset/vendor/select2/select2.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(asset('asset/script/main.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom/custom-table-datatable.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OHHJAY\Desktop\food_app\food_app\resources\views/admin/admin/pending.blade.php ENDPATH**/ ?>