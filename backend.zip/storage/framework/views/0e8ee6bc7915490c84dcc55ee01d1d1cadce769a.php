<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\OHHJAY\Desktop\food_app\food_app\resources\views/partials/success.blade.php ENDPATH**/ ?>