

<?php $__env->startSection('content'); ?>
    <main class="main">


        <div class="container m-5 justify-content-center">

            <div class="page-content">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9">

                            <div class="products mb-3">
                                <div class="row justify-content-center">
                                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                            <div class="product product-7 text-center">
                                                <figure class="product-media">

                                                    <a href="<?php echo e(route('menu', $menu->id)); ?>">
                                                        <img src="<?php echo e(asset('uploads/menu/' . $menu->menu_image)); ?>"
                                                            alt="Product image" class="product-image">
                                                    </a>

                                                    <div class="product-action-vertical">

                                                    </div><!-- End .product-action-vertical -->
                                                    <form method="POST" action="<?php echo e(route('cart.store')); ?>">
                                                        <div class="product-action">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="menu_price"
                                                                value="<?php echo e($menu->menu_price); ?>">
                                                            <input type="hidden" name="menu_name"
                                                                value="<?php echo e($menu->menu_name); ?>">
                                                            <input type="hidden" name="id" value="<?php echo e($menu->id); ?>">
                                                            <input type="hidden" name="qty" value="1">

                                                            <button href="#" type="submit" class="btn-product btn-cart"
                                                                title="Add to cart"><span>Add to cart</span></button>

                                                        </div><!-- End .product-action -->
                                                    </form>
                                                </figure><!-- End .product-media -->

                                                <div class="product-body">
                                                    <div class="product-cat">
                                                        <a
                                                            href="<?php echo e(route('category', $menu->category_id)); ?>"><?php echo e($menu->category); ?></a>
                                                    </div><!-- End .product-cat -->
                                                    <h3 class="product-title"><a
                                                            href="<?php echo e(route('menu', $menu->id)); ?>"><?php echo e($menu->menu_name); ?></a>
                                                    </h3><!-- End .product-title -->
                                                    <div class="product-price">
                                                        $<?php echo e($menu->menu_price); ?>

                                                    </div><!-- End .product-price -->
                                                    <!-- End .rating-container -->


                                                </div><!-- End .product-body -->
                                            </div><!-- End .product -->
                                        </div><!-- End .col-sm-6 col-lg-4 col-xl-3 -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div><!-- End .row -->
                            </div><!-- End .products -->


                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center">
                                    <li class="page-item disabled">
                                        <a class="page-link page-link-prev" href="#" aria-label="Previous" tabindex="-1"
                                            aria-disabled="true">
                                            <span aria-hidden="true"><i class="icon-long-arrow-left"></i></span>Prev
                                        </a>
                                    </li>
                                    <li class="page-item active" aria-current="page"><a class="page-link" href="#">1</a>
                                    </li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item-total">of 6</li>
                                    <li class="page-item">
                                        <a class="page-link page-link-next" href="#" aria-label="Next">
                                            Next <span aria-hidden="true"><i class="icon-long-arrow-right"></i></span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div><!-- End .col-lg-9 -->

                    </div><!-- End .row -->
                </div><!-- End .container -->
            </div><!-- End .page-content -->
        </div>
    </main><!-- End .main -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OHHJAY\Desktop\food_app\food_app\resources\views/shop.blade.php ENDPATH**/ ?>