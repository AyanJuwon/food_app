


<?php $__env->startSection('css'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/vendor/animate/animate.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/vendor/select2/select2.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/vendor/perfect-scrollbar/perfect-scrollbar.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/styles/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/styles/main.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-table100">
        <div class="wrap-table100">
            <div class="table100">
                <table>
                    <thead>
                        <tr class="table100-head">
                            <th class="column1">Date</th>
                            <th class="column2">Order ID</th>
                            <th class="column5">Order Quantity</th>
                            <th class="column6">Total</th>
                            <th class="column7">Reference</th>
                            <th class="column8">Status</th>
                            <th class="column9">See Details</th>
                        </tr>
                    </thead>
                    <tbody>


                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php $cart_quantity = 0; ?>
                            <tr>
                                <td class="column1"><?php echo e($order->updated_at); ?></td>
                                <td class="column2"><?php echo e($order->id); ?></td>
                                <td class="column5">
                                    <?php $__currentLoopData = \App\Models\OrderDetail::where('order_id', $order->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $cart_quantity += $orderDetail->quantity; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $cart_quantity; ?>
                                </td>

                                <td class="column6">$<?php echo e($order->total); ?></td>
                                <td class="column7"><?php echo e($order->payment_id); ?></td>
                                <td class="column8"><button type="submit" class="btn btn-success">Completed</button></td>
                                <td class="column9"><a href="<?php echo e(route('adminViewOrder', $order)); ?>"  class="text-primary">See Details</a></td>
                            </tr>
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('asset/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(asset('asset/vendor/bootstrap/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(asset('asset/vendor/select2/select2.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(asset('asset/script/main.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OHHJAY\Desktop\food_app\food_app\resources\views/admin/admin/completed.blade.php ENDPATH**/ ?>